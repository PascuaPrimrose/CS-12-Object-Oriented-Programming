
import java.awt.*;
import javax.swing.*;

public class GameObject implements Runnable  {

    public void paint(Graphics2D g) {

    }
    
    public void keyPressed(String key) {

    }
    
    public void keyReleased(String key) {
        
    }

    public void run() {
        
    }
}

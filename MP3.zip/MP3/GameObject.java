import java.applet.*;
import java.awt.*;
import javax.swing.*;

public class GameObject extends JApplet implements Runnable  {

    public void paint(Graphics2D g) {

    }
    
    public void keyPressed(String key) {

    }
    
    public void keyReleased(String key) {
        
    }
	
	
	// mouse methods. leftclick: button == 1, scrollbutton == 2, rightclick: button == 3
	public void mouseClicked(int xmouse, int ymouse, int button) {
		
	}
	
	public void mousePressed(int xmouse, int ymouse,int button) {
		
	}
	
	public void mouseReleased(int xmouse, int ymouse, int button) {
		
	}

	public void mouseDragged(int xmouse, int ymouse, int button) {
		
	}
	
	public void mouseMoved(int xmouse, int ymouse, int button) {
		
	}
	
    public void run() {
        
    }
}

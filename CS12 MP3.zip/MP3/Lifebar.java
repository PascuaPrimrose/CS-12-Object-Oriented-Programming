import java.awt.*;
import java.awt.image.*;

public class Lifebar extends GameObject{
	BufferedImage img;

public Lifebar(){

}
public void paint(Graphics2D g){ //This will be a bitch to code after
	g.fillRect(700,50,425,27); //Player 2 health Lalo na this one
	g.fillRect(100,50,425,27); //Player 1 health


}
}
